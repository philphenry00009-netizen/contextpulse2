# ContextPulse (Flutter)

Privacy-first ambient context engine. Pulse Cards: swipe right = done, swipe left = snooze, tap = why/edit.

## Architecture
```
lib/
  core/          theme, SecureStore (Keystore/Keychain), permissions
  domain/        entities.dart (ContextSignal, PulseCard, UserAction, ScheduleEvent, Habit)
                 context_evaluator.dart  <- pure rules engine + scoring
  data/          app_database.dart (SQLCipher AES-256), repositories.dart,
                 signal_collector.dart (5 signals), ai_enricher.dart (optional Gemini)
  application/   context_engine.dart (one tick), background_service.dart (WorkManager)
  presentation/  bloc/pulse_bloc.dart, pages/dashboard_page.dart, widgets/*
test/            context_evaluator_test.dart
```

## 1. Create the platform folders and add this code
```bash
flutter create --org dev.contextpulse --project-name context_pulse ctx_tmp
cp -r ctx_tmp/android ctx_tmp/ios ./     # from inside this project folder
rm -rf ctx_tmp
flutter pub get
```
(Or: `flutter create .` inside this folder; it keeps lib/ and pubspec.yaml.)

## 2. Android configuration
`android/app/build.gradle(.kts)`: set `minSdk = 24` (SQLCipher + WorkManager).

`android/app/src/main/AndroidManifest.xml`, before `<application>`:
```xml
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
<uses-permission android:name="android.permission.READ_CALENDAR"/>
<uses-permission android:name="android.permission.ACTIVITY_RECOGNITION"/>
```
On the `<application>` tag add `android:allowBackup="false"` (the DB key lives in the Keystore and
is not backed up, so a restored DB would be unreadable anyway).

## 3. iOS configuration (requires macOS + Xcode; iOS simulators do not run on Linux/Windows)
`ios/Podfile`: `platform :ios, '13.0'`

`ios/Runner/Info.plist`:
```xml
<key>NSCalendarsUsageDescription</key><string>Read-only, to show upcoming events.</string>
<key>NSCalendarsFullAccessUsageDescription</key><string>Read-only, to show upcoming events.</string>
<key>NSMotionUsageDescription</key><string>Detects walking/driving to time your cards.</string>
<key>UIBackgroundModes</key><array><string>fetch</string></array>
<key>BGTaskSchedulerPermittedIdentifiers</key>
<array><string>dev.contextpulse.tick</string></array>
```
`ios/Runner/AppDelegate.swift`, inside `didFinishLaunchingWithOptions` (before `return`):
```swift
import workmanager
WorkmanagerPlugin.registerPeriodicTask(withIdentifier: "dev.contextpulse.tick",
                                       frequency: NSNumber(value: 15 * 60))
```
iOS decides when background refresh runs (often much less than every 15 min). The app also ticks
every minute in the foreground and on resume, so cards are fresh whenever you open it.

## 4. Run
```bash
flutter devices
flutter run -d <android-emulator-or-usb-device-id>    # Android
open -a Simulator && flutter run                      # iOS (macOS only)
flutter test                                          # evaluator unit tests
```
Physical Android phones work via USB debugging (`adb devices`), and the real sensors give far
better activity/battery results than an emulator.

## 5. Testing the signals
- Battery: emulator Extended controls > Battery, set level < 20% and "Not charging".
- Network: toggle airplane mode; the offline banner appears, back online it clears and drains the queue.
- Calendar: add an event starting in 10-60 min (Calendar app) and grant the permission.
- Activity: emulator Extended controls > Virtual sensors; on a real phone just walk.
- Habits: Settings (tune icon) > add a habit for the current hour.
- Background: `adb shell dumpsys jobscheduler | grep contextpulse` shows the job; force it with
  `adb shell cmd jobscheduler run -f <your.package> <jobId>`.
- Battery cost: `adb shell dumpsys batterystats --reset`, use normally for 24 h, then
  `adb shell dumpsys batterystats <your.package>` and check the estimated drain.
  The design (15-min coarse job, no wake locks, no GPS, 2 s sensor sample) is aimed at under 1%/day,
  but it is a target to measure on your device, not a guarantee.

## Notes / honest limitations
- I could not compile this in my sandbox (no Flutter toolchain). Expect to fix small API drift
  after `flutter pub get`: package versions in pubspec move, especially `workmanager`,
  `device_calendar` timezone handling, `flutter_timezone`, and the Gemini model name in `ai_enricher.dart`.
- Encryption: SQLCipher AES-256 with a random 256-bit key held in Keystore/Keychain. The app refuses to
  open the DB if SQLCipher is not linked.
- "Driving" is only detected through the OS activity API; the accelerometer fallback reports
  stationary / walking / unknown.
- Repositories are concrete classes (no abstract interfaces) to keep the code compact; extract
  interfaces in `domain/` if you want to mock them.
- No analytics or telemetry code exists. The only network call is the optional Gemini enrichment.
