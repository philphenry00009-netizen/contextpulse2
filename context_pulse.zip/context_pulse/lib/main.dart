import 'package:flutter/material.dart';
import 'app.dart';
import 'application/background_service.dart';
import 'application/context_engine.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final engine = await ContextEngine.create(); // opens the encrypted DB
  engine.habits.seedIfEmpty();
  await BackgroundService.register();
  runApp(ContextPulseApp(engine: engine));
}
