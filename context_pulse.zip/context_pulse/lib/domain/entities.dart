import 'dart:convert';
import 'package:equatable/equatable.dart';

enum ActivityState { stationary, walking, driving, unknown }

enum NetworkState { wifi, cellular, offline }

enum CardType { calendar, habit, battery, offline, planning, wrapUp }

enum CardStatus { active, completed, dismissed }

enum ActionKind { completed, snoozed, dismissed, expense, note, reply, habitCheckIn }

T enumByName<T extends Enum>(List<T> values, Object? name, T fallback) {
  for (final v in values) {
    if (v.name == name) return v;
  }
  return fallback;
}

/// yyyymmdd as an int; used to build per-day card ids.
int dayKey(DateTime d) => d.year * 10000 + d.month * 100 + d.day;

// ------------------------------------------------------------ ScheduleEvent
class ScheduleEvent extends Equatable {
  const ScheduleEvent({
    required this.id,
    required this.title,
    required this.start,
    required this.end,
    this.location,
  });

  final String id;
  final String title;
  final DateTime start;
  final DateTime end;
  final String? location;

  Map<String, Object?> toMap() => {
        'id': id,
        'title': title,
        'start_ms': start.millisecondsSinceEpoch,
        'end_ms': end.millisecondsSinceEpoch,
        'location': location,
      };

  factory ScheduleEvent.fromMap(Map<String, Object?> m) => ScheduleEvent(
        id: m['id'] as String,
        title: (m['title'] as String?) ?? '',
        start: DateTime.fromMillisecondsSinceEpoch(m['start_ms'] as int),
        end: DateTime.fromMillisecondsSinceEpoch(m['end_ms'] as int),
        location: m['location'] as String?,
      );

  @override
  List<Object?> get props => [id, title, start, end, location];
}

// ------------------------------------------------------------ Habit
class Habit extends Equatable {
  const Habit({
    this.id,
    required this.title,
    required this.hour,
    this.windowMin = 120,
    this.lastDone,
  });

  final int? id;
  final String title;
  final int hour; // preferred hour of day, 0-23
  final int windowMin; // minutes after `hour` the habit stays relevant
  final DateTime? lastDone;

  factory Habit.fromMap(Map<String, Object?> m) => Habit(
        id: m['id'] as int,
        title: m['title'] as String,
        hour: m['hour'] as int,
        windowMin: m['window_min'] as int,
        lastDone: m['last_done_ms'] == null
            ? null
            : DateTime.fromMillisecondsSinceEpoch(m['last_done_ms'] as int),
      );

  @override
  List<Object?> get props => [id, title, hour, windowMin, lastDone];
}

// ------------------------------------------------------------ ContextSignal
class ContextSignal extends Equatable {
  const ContextSignal({
    required this.timestamp,
    required this.activity,
    required this.network,
    required this.batteryLevel,
    required this.isCharging,
    this.upcomingEvents = const [],
  });

  final DateTime timestamp;
  final ActivityState activity;
  final NetworkState network;
  final int batteryLevel; // 0-100
  final bool isCharging;
  final List<ScheduleEvent> upcomingEvents;

  int get hour => timestamp.hour;

  /// Next event that has not ended yet (may be in progress).
  ScheduleEvent? get nextEvent {
    final c = upcomingEvents.where((e) => e.end.isAfter(timestamp)).toList()
      ..sort((a, b) => a.start.compareTo(b.start));
    return c.isEmpty ? null : c.first;
  }

  int? get minutesToNextEvent => nextEvent?.start.difference(timestamp).inMinutes;

  @override
  List<Object?> get props =>
      [timestamp, activity, network, batteryLevel, isCharging, upcomingEvents];
}

// ------------------------------------------------------------ PulseCard
class PulseCard extends Equatable {
  const PulseCard({
    required this.id,
    required this.type,
    required this.title,
    required this.body,
    required this.score,
    required this.createdAt,
    required this.expiresAt,
    this.snoozedUntil,
    this.status = CardStatus.active,
    this.payload = const {},
    this.aiEnriched = false,
    this.userEdited = false,
  });

  final String id; // deterministic, e.g. "habit:3:20261016"
  final CardType type;
  final String title;
  final String body;
  final double score; // 0-100 priority
  final DateTime createdAt;
  final DateTime expiresAt;
  final DateTime? snoozedUntil;
  final CardStatus status;
  final Map<String, Object?> payload; // includes "why" explanation
  final bool aiEnriched;
  final bool userEdited;

  String get why => (payload['why'] as String?) ?? '';

  PulseCard copyWith({String? title, String? body, double? score}) => PulseCard(
        id: id,
        type: type,
        title: title ?? this.title,
        body: body ?? this.body,
        score: score ?? this.score,
        createdAt: createdAt,
        expiresAt: expiresAt,
        snoozedUntil: snoozedUntil,
        status: status,
        payload: payload,
        aiEnriched: aiEnriched,
        userEdited: userEdited,
      );

  factory PulseCard.fromMap(Map<String, Object?> m) => PulseCard(
        id: m['id'] as String,
        type: enumByName(CardType.values, m['type'], CardType.planning),
        title: m['title'] as String,
        body: (m['body'] as String?) ?? '',
        score: (m['score'] as num).toDouble(),
        createdAt: DateTime.fromMillisecondsSinceEpoch(m['created_ms'] as int),
        expiresAt: DateTime.fromMillisecondsSinceEpoch(m['expires_ms'] as int),
        snoozedUntil: m['snoozed_until_ms'] == null
            ? null
            : DateTime.fromMillisecondsSinceEpoch(m['snoozed_until_ms'] as int),
        status: enumByName(CardStatus.values, m['status'], CardStatus.active),
        payload: m['payload'] == null
            ? const {}
            : Map<String, Object?>.from(jsonDecode(m['payload'] as String) as Map),
        aiEnriched: (m['ai_enriched'] as int? ?? 0) == 1,
        userEdited: (m['user_edited'] as int? ?? 0) == 1,
      );

  @override
  List<Object?> get props =>
      [id, type, title, body, score, expiresAt, snoozedUntil, status, aiEnriched, userEdited];
}

// ------------------------------------------------------------ UserAction
class UserAction extends Equatable {
  const UserAction({
    this.id,
    this.cardId,
    required this.kind,
    this.note,
    this.amount,
    required this.createdAt,
  });

  final int? id;
  final String? cardId;
  final ActionKind kind;
  final String? note;
  final double? amount;
  final DateTime createdAt;

  factory UserAction.fromMap(Map<String, Object?> m) => UserAction(
        id: m['id'] as int,
        cardId: m['card_id'] as String?,
        kind: enumByName(ActionKind.values, m['kind'], ActionKind.note),
        note: m['note'] as String?,
        amount: (m['amount'] as num?)?.toDouble(),
        createdAt: DateTime.fromMillisecondsSinceEpoch(m['created_ms'] as int),
      );

  @override
  List<Object?> get props => [id, cardId, kind, note, amount, createdAt];
}
