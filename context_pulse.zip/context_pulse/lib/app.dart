import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'application/context_engine.dart';
import 'core/theme.dart';
import 'presentation/bloc/pulse_bloc.dart';
import 'presentation/pages/dashboard_page.dart';

class ContextPulseApp extends StatelessWidget {
  const ContextPulseApp({super.key, required this.engine});
  final ContextEngine engine;

  @override
  Widget build(BuildContext context) => BlocProvider(
        create: (_) => PulseBloc(engine)..add(const PulseStarted()),
        child: MaterialApp(
          title: 'ContextPulse',
          debugShowCheckedModeBanner: false,
          theme: Pulse.theme(),
          darkTheme: Pulse.theme(),
          themeMode: ThemeMode.dark, // dark by default
          home: const DashboardPage(),
        ),
      );
}
