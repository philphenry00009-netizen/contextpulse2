import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:workmanager/workmanager.dart';
import 'context_engine.dart';

const kTickTask = 'dev.contextpulse.tick';

/// Top-level entry point executed by WorkManager (Android) / BGTaskScheduler (iOS)
/// in a fresh headless isolate.
@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    WidgetsFlutterBinding.ensureInitialized();
    try {
      final engine = await ContextEngine.create();
      await engine.tick();
    } catch (e, st) {
      debugPrint('ContextPulse background tick failed: $e\n$st');
    }
    // Always report success: a periodic task re-runs on schedule anyway, and
    // returning false would add retry/back-off wake-ups (battery cost).
    return true;
  });
}

/// Registers one coarse periodic job (15 min = Android's minimum). Battery strategy:
/// no foreground service, no wake locks, no GPS, ~2 s accelerometer sample per run,
/// and the OS batches the job with other work (Doze / App Standby aware).
class BackgroundService {
  static Future<void> register() async {
    await Workmanager().initialize(callbackDispatcher, isInDebugMode: false);
    await Workmanager().registerPeriodicTask(
      'contextpulse.periodic',
      kTickTask,
      frequency: const Duration(minutes: 15),
      existingWorkPolicy: ExistingWorkPolicy.keep,
    );
  }
}
