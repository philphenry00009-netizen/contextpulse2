import 'package:connectivity_plus/connectivity_plus.dart';
import '../core/secure_store.dart';
import '../data/ai_enricher.dart';
import '../data/app_database.dart';
import '../data/repositories.dart';
import '../data/signal_collector.dart';
import '../domain/context_evaluator.dart';
import '../domain/entities.dart';

class TickResult {
  const TickResult(this.signal, this.score);
  final ContextSignal signal;
  final double score;
}

/// Orchestrates one pass: collect -> persist -> evaluate -> persist cards -> optional AI.
/// Used identically by the foreground UI and the background worker.
class ContextEngine {
  ContextEngine(AppDatabase db, {SignalCollector? collector, ContextEvaluator? evaluator})
      : pulses = PulseRepository(db.raw),
        actions = ActionRepository(db.raw),
        habits = HabitRepository(db.raw),
        events = EventRepository(db.raw),
        signals = SignalRepository(db.raw),
        queue = EnrichQueueRepository(db.raw),
        collector = collector ?? SignalCollector(),
        evaluator = evaluator ?? const ContextEvaluator() {
    enricher = AiEnricher(store, pulses, queue);
  }

  static Future<ContextEngine> create() async => ContextEngine(await AppDatabase.connect());

  final PulseRepository pulses;
  final ActionRepository actions;
  final HabitRepository habits;
  final EventRepository events;
  final SignalRepository signals;
  final EnrichQueueRepository queue;
  final SignalCollector collector;
  final ContextEvaluator evaluator;
  final SecureStore store = SecureStore();
  late final AiEnricher enricher;

  Future<TickResult> tick() async {
    final signal = await collector.collect();
    final score = evaluator.contextScore(signal);

    events.replaceAll(signal.upcomingEvents);
    final cards = evaluator.evaluate(signal, habits.all());
    pulses.upsertAll(cards, signal.timestamp);
    signals.insert(signal, score);
    signals.prune(signal.timestamp);
    pulses.deleteOld(signal.timestamp);

    // Optional AI layer: queue locally, drain only when online + opted in.
    if (await store.aiOptIn()) {
      queue.enqueueEligible(cards.map((c) => c.id).toList(), signal.timestamp);
      if (signal.network != NetworkState.offline) await enricher.processQueue();
    }
    return TickResult(signal, score);
  }

  /// Cheap helper for the UI to know whether the connectivity plugin sees any network.
  static bool isOffline(List<ConnectivityResult> r) =>
      r.isEmpty || r.every((e) => e == ConnectivityResult.none);
}
