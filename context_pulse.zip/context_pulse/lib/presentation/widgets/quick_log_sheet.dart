import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../core/theme.dart';
import '../../domain/entities.dart';
import '../bloc/pulse_bloc.dart';

enum QuickKind { expense, note, reply, habit }

/// One-tap logging. Everything is written locally and instantly (offline-safe).
Future<void> showQuickLogSheet(BuildContext context, QuickKind kind) {
  final bloc = context.read<PulseBloc>();
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    builder: (_) => BlocProvider.value(value: bloc, child: _QuickLogSheet(kind: kind)),
  );
}

class _QuickLogSheet extends StatefulWidget {
  const _QuickLogSheet({required this.kind});
  final QuickKind kind;
  @override
  State<_QuickLogSheet> createState() => _QuickLogSheetState();
}

class _QuickLogSheetState extends State<_QuickLogSheet> {
  final _amount = TextEditingController();
  final _text = TextEditingController();

  static const _replies = ['On my way', 'Running 10 min late', "Can't talk now, will call back", 'Thanks!'];

  @override
  void dispose() {
    _amount.dispose();
    _text.dispose();
    super.dispose();
  }

  void _done(String msg) {
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    final bloc = context.read<PulseBloc>();
    return Padding(
      padding: EdgeInsets.fromLTRB(20, 4, 20, 20 + MediaQuery.of(context).viewInsets.bottom),
      child: switch (widget.kind) {
        QuickKind.expense => _expense(bloc),
        QuickKind.note => _note(bloc),
        QuickKind.reply => _reply(bloc),
        QuickKind.habit => _habit(bloc),
      },
    );
  }

  Widget _expense(PulseBloc bloc) => Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(
          controller: _amount,
          autofocus: true,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(labelText: 'Amount', prefixIcon: Icon(Icons.payments_rounded)),
        ),
        const SizedBox(height: 10),
        TextField(controller: _text, decoration: const InputDecoration(labelText: 'What for? (optional)')),
        const SizedBox(height: 14),
        SizedBox(
          width: double.infinity,
          child: FilledButton(
            onPressed: () {
              final v = double.tryParse(_amount.text.replaceAll(',', '.'));
              if (v == null || v <= 0) return;
              bloc.add(PulseQuickLog(ActionKind.expense,
                  amount: v, note: _text.text.trim().isEmpty ? null : _text.text.trim()));
              _done('Expense logged');
            },
            child: const Text('Log expense'),
          ),
        ),
      ]);

  Widget _note(PulseBloc bloc) => Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(
            controller: _text,
            autofocus: true,
            maxLines: 4,
            decoration: const InputDecoration(labelText: 'Micro-note')),
        const SizedBox(height: 14),
        SizedBox(
          width: double.infinity,
          child: FilledButton(
            onPressed: () {
              if (_text.text.trim().isEmpty) return;
              bloc.add(PulseQuickLog(ActionKind.note, note: _text.text.trim()));
              _done('Note saved');
            },
            child: const Text('Save note'),
          ),
        ),
      ]);

  Widget _reply(PulseBloc bloc) => Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Tap to copy a quick reply', style: TextStyle(color: Pulse.textDim)),
          const SizedBox(height: 10),
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (final r in _replies)
              ActionChip(
                label: Text(r),
                onPressed: () async {
                  await Clipboard.setData(ClipboardData(text: r));
                  bloc.add(PulseQuickLog(ActionKind.reply, note: r));
                  _done('Copied: $r');
                },
              ),
          ]),
        ],
      );

  Widget _habit(PulseBloc bloc) {
    final habits = bloc.engine.habits.all();
    final today = dayKey(DateTime.now());
    return Column(mainAxisSize: MainAxisSize.min, children: [
      if (habits.isEmpty) const Text('No habits yet. Add some in settings.'),
      for (final h in habits)
        ListTile(
          leading: Icon(
              h.lastDone != null && dayKey(h.lastDone!) == today
                  ? Icons.check_circle_rounded
                  : Icons.radio_button_unchecked_rounded,
              color: Pulse.cyan),
          title: Text(h.title),
          onTap: () {
            bloc.add(PulseQuickLog(ActionKind.habitCheckIn, habitId: h.id, note: h.title));
            _done('Checked in: ${h.title}');
          },
        ),
    ]);
  }
}
