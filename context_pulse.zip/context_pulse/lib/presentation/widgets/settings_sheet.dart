import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../core/secure_store.dart';
import '../../core/theme.dart';
import '../bloc/pulse_bloc.dart';

Future<void> showSettingsSheet(BuildContext context) {
  final bloc = context.read<PulseBloc>();
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    builder: (_) => BlocProvider.value(value: bloc, child: const _SettingsSheet()),
  );
}

class _SettingsSheet extends StatefulWidget {
  const _SettingsSheet();
  @override
  State<_SettingsSheet> createState() => _SettingsSheetState();
}

class _SettingsSheetState extends State<_SettingsSheet> {
  final _store = SecureStore();
  final _key = TextEditingController();
  final _habit = TextEditingController();
  bool _ai = false;
  int _hour = 9;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final on = await _store.aiOptIn();
    final k = await _store.aiKey();
    if (!mounted) return;
    setState(() {
      _ai = on;
      _key.text = k ?? '';
    });
  }

  @override
  void dispose() {
    _key.dispose();
    _habit.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bloc = context.read<PulseBloc>();
    final habits = bloc.engine.habits.all();
    return Padding(
      padding: EdgeInsets.fromLTRB(20, 4, 20, 20 + MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Privacy', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          const Text('All context data stays in an AES-256 encrypted database on this device. '
              'No analytics are sent anywhere.',
              style: TextStyle(color: Pulse.textDim)),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('AI wording (optional)'),
            subtitle: const Text('Sends only generic card text (never calendar events) to Gemini '
                'using your own API key.'),
            value: _ai,
            onChanged: (v) async {
              await _store.setAiOptIn(v);
              setState(() => _ai = v);
            },
          ),
          if (_ai)
            TextField(
              controller: _key,
              obscureText: true,
              decoration: const InputDecoration(labelText: 'Gemini API key'),
              onChanged: (v) => _store.setAiKey(v),
            ),
          const SizedBox(height: 20),
          const Text('Habits', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
          for (final h in habits)
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(h.title),
              subtitle: Text('around ${h.hour.toString().padLeft(2, '0')}:00'),
              trailing: IconButton(
                icon: const Icon(Icons.delete_outline_rounded),
                onPressed: () {
                  bloc.engine.habits.remove(h.id!);
                  setState(() {});
                },
              ),
            ),
          Row(children: [
            Expanded(
                child: TextField(
                    controller: _habit, decoration: const InputDecoration(labelText: 'New habit'))),
            const SizedBox(width: 8),
            DropdownButton<int>(
              value: _hour,
              items: [for (var i = 0; i < 24; i++) DropdownMenuItem(value: i, child: Text('${i.toString().padLeft(2, '0')}:00'))],
              onChanged: (v) => setState(() => _hour = v ?? _hour),
            ),
            IconButton(
              icon: const Icon(Icons.add_circle_rounded, color: Pulse.cyan),
              onPressed: () {
                if (_habit.text.trim().isEmpty) return;
                bloc.engine.habits.add(_habit.text.trim(), _hour);
                _habit.clear();
                bloc.add(const PulseRefreshed());
                setState(() {});
              },
            ),
          ]),
        ]),
      ),
    );
  }
}
