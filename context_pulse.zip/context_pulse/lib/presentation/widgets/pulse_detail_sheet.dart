import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../core/theme.dart';
import '../../domain/entities.dart';
import '../bloc/pulse_bloc.dart';

/// Tap-to-expand drawer: explains WHY the card is shown and allows rapid edits.
Future<void> showPulseDetailSheet(BuildContext context, PulseCard card) {
  final bloc = context.read<PulseBloc>();
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    builder: (_) => BlocProvider.value(value: bloc, child: _DetailSheet(card: card)),
  );
}

class _DetailSheet extends StatefulWidget {
  const _DetailSheet({required this.card});
  final PulseCard card;
  @override
  State<_DetailSheet> createState() => _DetailSheetState();
}

class _DetailSheetState extends State<_DetailSheet> {
  late final _title = TextEditingController(text: widget.card.title);
  late final _body = TextEditingController(text: widget.card.body);

  @override
  void dispose() {
    _title.dispose();
    _body.dispose();
    super.dispose();
  }

  void _snooze(Duration d) {
    context.read<PulseBloc>().add(PulseCardSnoozed(widget.card, d));
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.card;
    return Padding(
      padding: EdgeInsets.fromLTRB(20, 4, 20, 20 + MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Priority ${c.score.round()} / 100',
                style: TextStyle(color: Pulse.forScore(c.score), fontWeight: FontWeight.w600)),
            if (c.why.isNotEmpty) ...[
              const SizedBox(height: 4),
              Text('Why now: ${c.why}', style: const TextStyle(color: Pulse.textDim)),
            ],
            if (c.aiEnriched)
              const Padding(
                padding: EdgeInsets.only(top: 4),
                child: Text('Wording refined by AI (opt-in)',
                    style: TextStyle(color: Pulse.textDim, fontSize: 12)),
              ),
            const SizedBox(height: 16),
            TextField(controller: _title, decoration: const InputDecoration(labelText: 'Title')),
            const SizedBox(height: 10),
            TextField(
                controller: _body,
                maxLines: 3,
                decoration: const InputDecoration(labelText: 'Details')),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () {
                    context
                        .read<PulseBloc>()
                        .add(PulseCardEdited(c.id, _title.text.trim(), _body.text.trim()));
                    Navigator.pop(context);
                  },
                  child: const Text('Save edit'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: FilledButton(
                  onPressed: () {
                    context.read<PulseBloc>().add(PulseCardCompleted(c));
                    Navigator.pop(context);
                  },
                  child: const Text('Done'),
                ),
              ),
            ]),
            const SizedBox(height: 14),
            const Text('Snooze', style: TextStyle(color: Pulse.textDim)),
            const SizedBox(height: 6),
            Wrap(spacing: 8, children: [
              for (final d in const [Duration(minutes: 15), Duration(hours: 1), Duration(hours: 3)])
                ActionChip(
                    label: Text(d.inMinutes < 60 ? '${d.inMinutes} min' : '${d.inHours} h'),
                    onPressed: () => _snooze(d)),
              ActionChip(
                label: const Text('Dismiss'),
                onPressed: () {
                  context.read<PulseBloc>().add(PulseCardDismissed(c));
                  Navigator.pop(context);
                },
              ),
            ]),
          ],
        ),
      ),
    );
  }
}
