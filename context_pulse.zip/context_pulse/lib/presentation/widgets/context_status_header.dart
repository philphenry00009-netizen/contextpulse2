import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../domain/entities.dart';
import '../bloc/pulse_bloc.dart';

class ContextStatusHeader extends StatelessWidget {
  const ContextStatusHeader({super.key, required this.state, required this.onSettings});
  final PulseState state;
  final VoidCallback onSettings;

  String get _greeting {
    final h = DateTime.now().hour;
    return h < 5 ? 'Late night' : h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening';
  }

  @override
  Widget build(BuildContext context) {
    final s = state.signal;
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              SizedBox(
                width: 64,
                height: 64,
                child: Stack(alignment: Alignment.center, children: [
                  TweenAnimationBuilder<double>(
                    tween: Tween(begin: 0, end: state.contextScore / 100),
                    duration: const Duration(milliseconds: 700),
                    curve: Curves.easeOutCubic,
                    builder: (_, v, __) => SizedBox.expand(
                      child: CircularProgressIndicator(
                          value: v, strokeWidth: 5, color: Pulse.cyan, backgroundColor: Pulse.surfaceHi),
                    ),
                  ),
                  Text(state.contextScore.round().toString(),
                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                ]),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(_greeting, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
                    const Text('Context score', style: TextStyle(color: Pulse.textDim)),
                  ],
                ),
              ),
              if (state.loading)
                const Padding(
                  padding: EdgeInsets.only(right: 8),
                  child: SizedBox(
                      width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)),
                ),
              IconButton(onPressed: onSettings, icon: const Icon(Icons.tune_rounded)),
            ],
          ),
          const SizedBox(height: 14),
          if (s != null)
            Wrap(spacing: 8, runSpacing: 8, children: [
              _chip(_activityIcon(s.activity), s.activity.name),
              _chip(_netIcon(s.network), s.network.name),
              _chip(s.isCharging ? Icons.battery_charging_full_rounded : Icons.battery_std_rounded,
                  '${s.batteryLevel}%'),
              if (s.nextEvent != null) _chip(Icons.event_rounded, _nextLabel(s)),
            ]),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 250),
            child: state.offline
                ? Container(
                    key: const ValueKey('offline'),
                    margin: const EdgeInsets.only(top: 12),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                        color: Pulse.warn.withOpacity(0.14),
                        borderRadius: BorderRadius.circular(14)),
                    child: Row(children: [
                      const Icon(Icons.cloud_off_rounded, color: Pulse.warn, size: 18),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          state.pendingQueue > 0
                              ? 'Offline - ${state.pendingQueue} queued, will sync automatically'
                              : 'Offline - everything still works locally',
                          style: const TextStyle(color: Pulse.warn),
                        ),
                      ),
                    ]),
                  )
                : const SizedBox.shrink(key: ValueKey('online')),
          ),
        ],
      ),
    );
  }

  String _nextLabel(ContextSignal s) {
    final m = s.minutesToNextEvent ?? 0;
    return m <= 0 ? 'now: ${s.nextEvent!.title}' : 'in ${m}m: ${s.nextEvent!.title}';
  }

  IconData _activityIcon(ActivityState a) => switch (a) {
        ActivityState.stationary => Icons.chair_alt_rounded,
        ActivityState.walking => Icons.directions_walk_rounded,
        ActivityState.driving => Icons.directions_car_rounded,
        ActivityState.unknown => Icons.help_outline_rounded,
      };

  IconData _netIcon(NetworkState n) => switch (n) {
        NetworkState.wifi => Icons.wifi_rounded,
        NetworkState.cellular => Icons.signal_cellular_alt_rounded,
        NetworkState.offline => Icons.wifi_off_rounded,
      };

  Widget _chip(IconData i, String t) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(color: Pulse.surfaceHi, borderRadius: BorderRadius.circular(20)),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(i, size: 15, color: Pulse.cyan),
          const SizedBox(width: 6),
          ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 180),
            child: Text(t,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 12.5, color: Pulse.textDim)),
          ),
        ]),
      );
}
