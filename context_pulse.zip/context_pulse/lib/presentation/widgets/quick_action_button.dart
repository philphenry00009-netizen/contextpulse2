import 'package:flutter/material.dart';
import '../../core/theme.dart';

class QuickActionButton extends StatelessWidget {
  const QuickActionButton({super.key, required this.icon, required this.label, required this.onTap});
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Expanded(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: Material(
            color: Pulse.surfaceHi,
            borderRadius: BorderRadius.circular(16),
            child: InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: onTap,
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Icon(icon, color: Pulse.cyan),
                  const SizedBox(height: 4),
                  Text(label, style: const TextStyle(fontSize: 12, color: Pulse.textDim)),
                ]),
              ),
            ),
          ),
        ),
      );
}
