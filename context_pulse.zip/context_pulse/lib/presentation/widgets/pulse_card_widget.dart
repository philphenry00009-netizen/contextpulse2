import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../domain/entities.dart';

IconData iconForType(CardType t) => switch (t) {
      CardType.calendar => Icons.event_rounded,
      CardType.habit => Icons.bolt_rounded,
      CardType.battery => Icons.battery_alert_rounded,
      CardType.offline => Icons.cloud_off_rounded,
      CardType.planning => Icons.wb_twilight_rounded,
      CardType.wrapUp => Icons.nights_stay_rounded,
    };

/// A swipeable card. Right = complete, left = snooze, tap = details.
/// Entrance is a staggered fade + rise; removal uses Dismissible's collapse animation.
class PulseCardWidget extends StatelessWidget {
  const PulseCardWidget({
    super.key,
    required this.card,
    required this.index,
    required this.onComplete,
    required this.onSnooze,
    required this.onTap,
  });

  final PulseCard card;
  final int index;
  final VoidCallback onComplete;
  final VoidCallback onSnooze;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final accent = Pulse.forScore(card.score);
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 320 + index * 90),
      curve: Curves.easeOutCubic,
      builder: (context, t, child) => Opacity(
        opacity: t,
        child: Transform.translate(offset: Offset(0, 28 * (1 - t)), child: child),
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 6, 16, 6),
        child: Dismissible(
          key: ValueKey('d-${card.id}'),
          background: _swipeBg(Pulse.cyan, Icons.check_rounded, 'Done', Alignment.centerLeft),
          secondaryBackground:
              _swipeBg(Pulse.slate, Icons.snooze_rounded, 'Snooze', Alignment.centerRight),
          onDismissed: (dir) =>
              dir == DismissDirection.startToEnd ? onComplete() : onSnooze(),
          child: Material(
            color: Pulse.surface,
            borderRadius: BorderRadius.circular(22),
            child: InkWell(
              borderRadius: BorderRadius.circular(22),
              onTap: onTap,
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(color: accent.withOpacity(0.45)),
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [accent.withOpacity(0.10), Colors.transparent],
                  ),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                          color: accent.withOpacity(0.15), shape: BoxShape.circle),
                      child: Icon(iconForType(card.type), color: accent),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(card.title,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
                          const SizedBox(height: 4),
                          Text(card.body,
                              maxLines: 3,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(color: Pulse.textDim, height: 1.35)),
                          const SizedBox(height: 10),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(4),
                            child: LinearProgressIndicator(
                              value: card.score / 100,
                              minHeight: 3,
                              color: accent,
                              backgroundColor: Pulse.surfaceHi,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _swipeBg(Color c, IconData icon, String label, Alignment a) => Container(
        alignment: a,
        padding: const EdgeInsets.symmetric(horizontal: 24),
        decoration:
            BoxDecoration(color: c.withOpacity(0.18), borderRadius: BorderRadius.circular(22)),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, color: c),
          const SizedBox(width: 8),
          Text(label, style: TextStyle(color: c, fontWeight: FontWeight.w600)),
        ]),
      );
}
