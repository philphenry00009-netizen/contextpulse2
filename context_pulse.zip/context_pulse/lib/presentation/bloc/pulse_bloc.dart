import 'dart:async';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../application/context_engine.dart';
import '../../core/permissions.dart';
import '../../domain/entities.dart';

// ------------------------------------------------------------------ events
sealed class PulseEvent {
  const PulseEvent();
}

class PulseStarted extends PulseEvent {
  const PulseStarted();
}

class PulseRefreshed extends PulseEvent {
  const PulseRefreshed();
}

class PulseCardCompleted extends PulseEvent {
  const PulseCardCompleted(this.card);
  final PulseCard card;
}

class PulseCardSnoozed extends PulseEvent {
  const PulseCardSnoozed(this.card, [this.duration = const Duration(minutes: 30)]);
  final PulseCard card;
  final Duration duration;
}

class PulseCardDismissed extends PulseEvent {
  const PulseCardDismissed(this.card);
  final PulseCard card;
}

class PulseCardEdited extends PulseEvent {
  const PulseCardEdited(this.id, this.title, this.body);
  final String id, title, body;
}

class PulseQuickLog extends PulseEvent {
  const PulseQuickLog(this.kind, {this.note, this.amount, this.habitId});
  final ActionKind kind;
  final String? note;
  final double? amount;
  final int? habitId;
}

// ------------------------------------------------------------------ state
class PulseState extends Equatable {
  const PulseState({
    this.cards = const [],
    this.signal,
    this.contextScore = 0,
    this.pendingQueue = 0,
    this.loading = true,
    this.offline = false,
  });

  final List<PulseCard> cards;
  final ContextSignal? signal;
  final double contextScore;
  final int pendingQueue;
  final bool loading;
  final bool offline;

  PulseState copyWith({
    List<PulseCard>? cards,
    ContextSignal? signal,
    double? contextScore,
    int? pendingQueue,
    bool? loading,
    bool? offline,
  }) =>
      PulseState(
        cards: cards ?? this.cards,
        signal: signal ?? this.signal,
        contextScore: contextScore ?? this.contextScore,
        pendingQueue: pendingQueue ?? this.pendingQueue,
        loading: loading ?? this.loading,
        offline: offline ?? this.offline,
      );

  @override
  List<Object?> get props => [cards, signal, contextScore, pendingQueue, loading, offline];
}

// ------------------------------------------------------------------ bloc
class PulseBloc extends Bloc<PulseEvent, PulseState> {
  PulseBloc(this.engine) : super(const PulseState()) {
    on<PulseStarted>(_onStarted);
    on<PulseRefreshed>((e, emit) => _tick(emit));
    on<PulseCardCompleted>(_onCompleted);
    on<PulseCardSnoozed>(_onSnoozed);
    on<PulseCardDismissed>(_onDismissed);
    on<PulseCardEdited>(_onEdited);
    on<PulseQuickLog>(_onQuickLog);
  }

  final ContextEngine engine;
  StreamSubscription<List<ConnectivityResult>>? _conn;
  Timer? _timer;
  bool _ticking = false;

  Future<void> _onStarted(PulseStarted e, Emitter<PulseState> emit) async {
    // Show whatever the background worker already computed, instantly.
    emit(state.copyWith(cards: engine.pulses.active(), pendingQueue: engine.queue.count()));
    // Foreground cadence: 60 s while visible. Background worker covers the rest.
    _timer = Timer.periodic(const Duration(minutes: 1), (_) => add(const PulseRefreshed()));
    // Reconnect -> refresh immediately, which also drains the offline queue.
    _conn = Connectivity().onConnectivityChanged.listen((_) => add(const PulseRefreshed()));
    await _tick(emit);
    await Permissions.requestAll(); // after first paint
    await _tick(emit);
  }

  Future<void> _tick(Emitter<PulseState> emit) async {
    if (_ticking) return;
    _ticking = true;
    try {
      emit(state.copyWith(loading: true));
      final r = await engine.tick();
      emit(state.copyWith(
        cards: engine.pulses.active(),
        signal: r.signal,
        contextScore: r.score,
        pendingQueue: engine.queue.count(),
        offline: r.signal.network == NetworkState.offline,
        loading: false,
      ));
    } catch (e, st) {
      debugPrint('tick failed: $e\n$st');
      emit(state.copyWith(loading: false));
    } finally {
      _ticking = false;
    }
  }

  void _reload(Emitter<PulseState> emit) => emit(state.copyWith(
      cards: engine.pulses.active(), pendingQueue: engine.queue.count()));

  Future<void> _onCompleted(PulseCardCompleted e, Emitter<PulseState> emit) async {
    final now = DateTime.now();
    engine.pulses.setStatus(e.card.id, CardStatus.completed);
    engine.actions.log(UserAction(cardId: e.card.id, kind: ActionKind.completed, createdAt: now));
    final hid = e.card.payload['habitId'];
    if (hid is int) engine.habits.markDone(hid, now);
    _reload(emit);
  }

  Future<void> _onSnoozed(PulseCardSnoozed e, Emitter<PulseState> emit) async {
    final now = DateTime.now();
    engine.pulses.snooze(e.card.id, now.add(e.duration));
    engine.actions.log(UserAction(
        cardId: e.card.id,
        kind: ActionKind.snoozed,
        note: '${e.duration.inMinutes}m',
        createdAt: now));
    _reload(emit);
  }

  Future<void> _onDismissed(PulseCardDismissed e, Emitter<PulseState> emit) async {
    engine.pulses.setStatus(e.card.id, CardStatus.dismissed);
    engine.actions.log(
        UserAction(cardId: e.card.id, kind: ActionKind.dismissed, createdAt: DateTime.now()));
    _reload(emit);
  }

  Future<void> _onEdited(PulseCardEdited e, Emitter<PulseState> emit) async {
    engine.pulses.updateText(e.id, e.title, e.body);
    _reload(emit);
  }

  Future<void> _onQuickLog(PulseQuickLog e, Emitter<PulseState> emit) async {
    final now = DateTime.now();
    engine.actions.log(UserAction(kind: e.kind, note: e.note, amount: e.amount, createdAt: now));
    if (e.kind == ActionKind.habitCheckIn && e.habitId != null) {
      engine.habits.markDone(e.habitId!, now);
      engine.pulses.setStatus('habit:${e.habitId}:${dayKey(now)}', CardStatus.completed);
    }
    _reload(emit);
  }

  @override
  Future<void> close() {
    _timer?.cancel();
    _conn?.cancel();
    return super.close();
  }
}
