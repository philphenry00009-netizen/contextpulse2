import 'package:flutter/material.dart';

/// Design tokens: dark-first, neon cyan + electric slate accents.
class Pulse {
  static const bg = Color(0xFF0A0E14);
  static const surface = Color(0xFF131A25);
  static const surfaceHi = Color(0xFF1B2433);
  static const cyan = Color(0xFF00E5FF);
  static const slate = Color(0xFF7C93C3);
  static const dim = Color(0xFF5B6B85);
  static const warn = Color(0xFFFFB454);
  static const text = Color(0xFFE6EDF7);
  static const textDim = Color(0xFF9AA8BF);

  /// Higher score -> brighter accent.
  static Color forScore(double s) => s >= 75 ? cyan : (s >= 50 ? slate : dim);

  static ThemeData theme() {
    final base = ThemeData.dark(useMaterial3: true);
    return base.copyWith(
      scaffoldBackgroundColor: bg,
      colorScheme: const ColorScheme.dark(
          primary: cyan, secondary: slate, surface: surface),
      textTheme: base.textTheme.apply(bodyColor: text, displayColor: text),
      bottomSheetTheme: const BottomSheetThemeData(
        backgroundColor: surface,
        showDragHandle: true,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: surfaceHi,
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
      ),
      snackBarTheme: const SnackBarThemeData(
          behavior: SnackBarBehavior.floating, backgroundColor: surfaceHi),
    );
  }
}
