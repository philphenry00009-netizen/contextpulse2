import 'dart:math';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Keys and settings live in Android Keystore / iOS Keychain, never in the DB.
class SecureStore {
  static const _s = FlutterSecureStorage(
      aOptions: AndroidOptions(encryptedSharedPreferences: true));

  /// 256-bit SQLCipher key (64 hex chars), generated once with a CSPRNG.
  Future<String> dbKey() async {
    var k = await _s.read(key: 'db_key');
    if (k == null) {
      final r = Random.secure();
      k = List.generate(32, (_) => r.nextInt(256).toRadixString(16).padLeft(2, '0'))
          .join();
      await _s.write(key: 'db_key', value: k);
    }
    return k;
  }

  Future<bool> aiOptIn() async => (await _s.read(key: 'ai_opt_in')) == '1';
  Future<void> setAiOptIn(bool v) => _s.write(key: 'ai_opt_in', value: v ? '1' : '0');
  Future<String?> aiKey() => _s.read(key: 'ai_key');
  Future<void> setAiKey(String v) => _s.write(key: 'ai_key', value: v.trim());
}
