import 'package:device_calendar/device_calendar.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_activity_recognition/flutter_activity_recognition.dart';

/// Requests only what the signals need. Everything degrades gracefully if denied.
class Permissions {
  static Future<void> requestAll() async {
    try {
      final cal = DeviceCalendarPlugin();
      final has = await cal.hasPermissions();
      if (!(has.isSuccess && (has.data ?? false))) await cal.requestPermissions();
    } catch (e) {
      debugPrint('calendar permission: $e');
    }
    try {
      final ar = FlutterActivityRecognition.instance;
      if (await ar.checkPermission() != ActivityPermission.GRANTED) {
        await ar.requestPermission();
      }
    } catch (e) {
      debugPrint('activity permission: $e');
    }
  }
}
