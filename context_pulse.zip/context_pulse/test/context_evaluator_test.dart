import 'package:context_pulse/domain/context_evaluator.dart';
import 'package:context_pulse/domain/entities.dart';
import 'package:flutter_test/flutter_test.dart';

ContextSignal sig({
  DateTime? at,
  ActivityState a = ActivityState.stationary,
  NetworkState n = NetworkState.wifi,
  int battery = 80,
  bool charging = false,
  List<ScheduleEvent> events = const [],
}) =>
    ContextSignal(
      timestamp: at ?? DateTime(2026, 10, 16, 14, 0),
      activity: a,
      network: n,
      batteryLevel: battery,
      isCharging: charging,
      upcomingEvents: events,
    );

void main() {
  const ev = ContextEvaluator();

  test('imminent event outranks everything and carries a reason', () {
    final t = DateTime(2026, 10, 16, 14, 0);
    final s = sig(events: [
      ScheduleEvent(id: 'a', title: 'Standup', start: t.add(const Duration(minutes: 10)), end: t.add(const Duration(minutes: 40)), location: 'Room 2'),
    ]);
    final cards = ev.evaluate(s, const []);
    expect(cards.first.type, CardType.calendar);
    expect(cards.first.score, greaterThan(80));
    expect(cards.first.why, isNotEmpty);
  });

  test('low battery produces a high-priority card; charging suppresses it', () {
    expect(ev.evaluate(sig(battery: 8), const []).first.type, CardType.battery);
    expect(ev.evaluate(sig(battery: 8, charging: true), const []), isEmpty);
  });

  test('habit in window shows once; done today hides it', () {
    final h = Habit(id: 1, title: 'Water', hour: 14);
    expect(ev.evaluate(sig(), [h]).any((c) => c.type == CardType.habit), isTrue);
    final done = Habit(id: 1, title: 'Water', hour: 14, lastDone: DateTime(2026, 10, 16, 9));
    expect(ev.evaluate(sig(), [done]).any((c) => c.type == CardType.habit), isFalse);
  });

  test('driving mutes non-urgent cards and lowers context score', () {
    final h = Habit(id: 1, title: 'Water', hour: 14);
    expect(ev.evaluate(sig(a: ActivityState.driving), [h]).where((c) => c.type == CardType.habit), isEmpty);
    expect(ev.contextScore(sig(a: ActivityState.driving)), lessThan(ev.contextScore(sig())));
  });

  test('never returns more than 5 cards, sorted by score', () {
    final habits = [for (var i = 0; i < 9; i++) Habit(id: i, title: 'H$i', hour: 14)];
    final cards = ev.evaluate(sig(battery: 5), habits);
    expect(cards.length, lessThanOrEqualTo(5));
    for (var i = 1; i < cards.length; i++) {
      expect(cards[i - 1].score, greaterThanOrEqualTo(cards[i].score));
    }
  });
}
